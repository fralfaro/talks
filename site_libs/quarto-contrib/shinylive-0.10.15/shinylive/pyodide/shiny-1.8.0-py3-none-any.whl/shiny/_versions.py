shiny_html_deps = "1.14.0.9000"
bslib = "0.12.0.9000"
htmltools = "0.5.9.9000"
bootstrap = "5.3.8"
requirejs = "2.3.6"

__all__ = (
    "shiny_html_deps",
    "bslib",
    "htmltools",
    "bootstrap",
    "requirejs",
)
