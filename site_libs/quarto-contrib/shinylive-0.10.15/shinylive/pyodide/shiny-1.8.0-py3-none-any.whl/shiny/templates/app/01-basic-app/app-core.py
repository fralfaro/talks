from shiny import App, render, ui

app_ui = ui.page_fluid(
    ui.panel_title("Hello Shiny!"),
    ui.input_slider("n", "N", 0, 100, 20),
    ui.output_code("txt"),
)


def server(input, output, session):
    @render.code
    def txt():
        return f"n*2 is {input.n() * 2}"


app = App(app_ui, server)
